<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class product extends Model
{
    public $timestamps = false;
    protected $primaryKey = 'p_code';
    protected $fillable = [
        'vander',
        'p_code',
        'p_name',
        'p_prize',
        'pd_price',
        'description'
    ];

}
