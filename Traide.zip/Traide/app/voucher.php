<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class voucher extends Model
{
    public $timestamps = false;
    protected $primaryKey = 'v_code';
    protected $fillable = [

        'v_code',
        'v_name',
        'v_prize',
        'v_ex_date',
        't_can'
    ];
}
