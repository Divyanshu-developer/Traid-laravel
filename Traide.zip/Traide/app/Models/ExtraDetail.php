<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class ExtraDetail extends Model
{
    protected $fillable = [
        'user_id',
        'dealer_id',
        'aadhar_card',
        'pan_card',
        'dob',
        'address',
        'gender',
        'city_id',
        'zip_code',
    ];
}
