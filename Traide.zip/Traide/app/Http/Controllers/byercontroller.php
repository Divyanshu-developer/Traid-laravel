<?php

namespace App\Http\Controllers;
use App\User;
use App\voucher;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\product;
use Illuminate\Support\Facades\Mail;

class byercontroller extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }
    public function byer()
    {

        $user=Auth::user();
        return view('byer.bhome',compact('user'));


    }
    public function product()
    {
//        $product = \App\product::all();
//        return view('byer.product',[
//            'product'=>$product]);
        $products = product::all();
        return view('byer.product',['products'=>$products]);

    }

    public function voucher()
    {

        $voucher = voucher::all();
        return view('byer.voucher',['voucher'=>$voucher]);

    }
//
//    public function byer()
//    {
//        $byer = user::all();
//        return view('byer.bhome')->with('users', $byer);
//    }
}
