<?php

namespace App\Http\Controllers;
use App\product;
use App\User;
use App\voucher;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
class userscontroller extends Controller
{
    public function users()
    {
        $users = user::all();
        return view('admin.users')->with('users', $users);
    }

    public function vender()
    {
        $users = user::where('user_type_id','4')->get();
        return view('admin.vender')->with('users', $users);
    }

    public function buyers()
    {
        $users = user::where('user_type_id','2')->get();
        return view('admin.buyers')->with('users', $users);
    }

    public function dealer()
    {
        $users = user::where('user_type_id','1')->get();
        return view('admin.dealer')->with('users', $users);
    }


    public function products()
    {
        $products = product::all();
        return view('admin.products')->with('products', $products);
    }
    public function save(Request $request){
        $products = new product;
        $products->vander = $request->input('vander');
        $products->p_code = $request->input('p_code');
        $products->p_name = $request->input('p_name');
        $products->p_prize = $request->input('p_prize');
        $products->pd_price = $request->input('pd_price');
        $products->description = $request->input('description');

        $products->save();
        return redirect( '/products')->with('status', 'Data is update');

    }

    public function deleted(Request $request, $p_code)
    {
        $products = product::findorFail($p_code);
        $products->delete();
        return redirect('/products')->with('status', 'Data is Delete');

    }
    public function products_edit(Request $request, $p_code)
    {
        $products = product::findorFail($p_code);
        return view('admin.productsedit')->with('products', $products);

    }


    public function products_update(Request $request, $p_code)
    {
        $products= product::find($p_code);
        $products->vander = $request->input('vander');
        $products->p_code = $request->input('p_code');
        $products->p_name = $request->input('p_name');
        $products->p_prize = $request->input('p_prize');
        $products->pd_price = $request->input('pd_price');
        $products->description = $request->input('description');
        $products->update();
        return redirect('/products')->with('status', 'Data is update');


    }

    public function vouchers()
    {
        $vouchers = voucher::all();
        return view('admin.vouchers')->with('vouchers',$vouchers);
    }


    public function savevouchers(Request $request){
        $vouchers = new voucher;
        $vouchers->v_code = $request->input('v_code');
        $vouchers->v_name = $request->input('v_name');
        $vouchers->v_prize = $request->input('v_prize');
        $vouchers->v_ex_date = $request->input('v_ex_date');
        $vouchers->t_can = $request->input('t_can');
        $vouchers->save();
        return redirect( '/vouchers')->with('status', 'Data is update');

    }

    public function vouchersdeleted(Request $request , $v_code)
    {
        $vouchers =voucher::findorFail($v_code);
        $vouchers->delete();
        return redirect('/vouchers')->with('status', 'Data is Delete');

    }

    public function vouchers_edits(Request $request,$v_code)
    {
        $vouchers = voucher::findorFail($v_code);
        return view('admin.vouchers_edits')->with('vouchers',$vouchers);
    }

    public function vouchers_updates(Request $request,$v_code )
    {
        $vouchers = voucher::find($v_code);
        $vouchers->v_code = $request->input('v_code');
        $vouchers->v_name = $request->input('v_name');
        $vouchers->v_prize = $request->input('v_prize');
        $vouchers->v_ex_date = $request->input('v_ex_date');
        $vouchers->t_can = $request->input('t_can');
        $vouchers->update();
        return redirect( '/vouchers')->with('status', 'Data is update');
    }

    public function user_edit(Request $request, $id)
    {
        $users = user::findorFail($id);
        return view('admin.user_edit')->with('users', $users);

    }


    public function user_update(Request $request, $id)
    {
        $users = user::find($id);
        $users->name = $request->input('name');
        $users->email = $request->input('email');
        $users->phone = $request->input('phone');
        $users->update();
        return redirect('/users')->with('status', 'Data is update');


    }
    public function destroy(Request $request, $id)
    {
        $users = user::findorFail($id);
        $users->delete();
        return redirect('/users')->with('status', 'Data is Delete');

    }

}
