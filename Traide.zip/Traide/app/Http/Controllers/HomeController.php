<?php

namespace App\Http\Controllers;

use App\Models\ExtraDetail;
use App\Models\State;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $user = Auth::user();

        $extra_details = ExtraDetail::query()->where('user_id', '=', $user->id)->get()->toArray();

        if (!count($extra_details))
        {
            return view('extra_details');
        }

        return view('home');
    }

    public function saveExtraDetail() {

        if (Auth::user()->user_type_id == 2) {
            if (!User::query()->where('unique_id', '=', \request('dealer_id'))->count())
            {
                return redirect()->back()->withErrors([
                    'dealer_id' => 'Dealer id Not Found Please check!'
                ])->withInput(\request()->all());
            }
            $validation = [
                'aadharno' => 'required|numeric|digits:12',
                'panno' => 'required|max:10',
                'dob' => 'required|date',
                'gender' => 'required|numeric',
                'address' => 'required|string',
                'city_id' => 'required|numeric',
                'zip' => 'required|numeric|digits:6',
                'dealer_id' => 'required|numeric|digits:10',
            ];
        }
        else
            $validation = [
                'aadharno' => 'required|numeric|digits:12',
                'panno' => 'required|max:10',
                'dob' => 'required|date',
                'gender' => 'required|numeric',
                'address' => 'required|string',
                'city_id' => 'required|numeric',
                'zip' => 'required|numeric|digits:6',
            ];

        $validator = Validator::make(\request()->all(), $validation);

        if ($validator->fails())
        {
            return redirect()->back()->withErrors($validator->errors())->withInput(\request()->all());
        }

        ExtraDetail::query()->create([
            'user_id' => Auth::id(),
            'dealer_id' => \request('dealer_id'),
            'aadhar_card' => \request('aadharno'),
            'pan_card' => \request('panno'),
            'dob' => \request('dob'),
            'gender' => \request('gender'),
            'address' => \request('address'),
            'city_id' => \request('city_id'),
            'zip_code' => \request('zip'),
        ]);

        return redirect()->back()->with('success', 'Successfully Updated Profile!');
    }
}
