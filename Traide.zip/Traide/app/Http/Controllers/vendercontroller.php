<?php

namespace App\Http\Controllers;

use App\product;
use App\voucher;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class vendercontroller extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function vender()
    {

        $user=Auth::user();
        return view('vender.vhome',compact('user'));

    }
    public function prod()
    {
        $products = product::all();
        return view('vender.prod',['products'=>$products]);

    }
    public function store(Request $request ){
        $products = new product();
        $products->vander = $request->input('vander');
        $products->p_code = $request->input('p_code');
        $products->p_name = $request->input('p_name');
        $products->p_prize = $request->input('p_prize');
        $products->pd_price = $request->input('pd_price');
        $products->description = $request->input('description');
        $products->save();
        return redirect( '/prod')->with('status', 'Data is update');

    }

    public function delete(Request $request, $p_code)
    {
        $products = product::findorFail($p_code);
        $products->delete();
        return redirect('/prod')->with('status', 'Data is Delete');

    }
    public function vouch()
    {
        $vouchers = voucher::all();
        return view('vender.vouch')->with('vouchers',$vouchers);
    }
    public function savevouch(Request $request){
        $vouchers = new voucher;
        $vouchers->v_code = $request->input('v_code');
        $vouchers->v_name = $request->input('v_name');
        $vouchers->v_prize = $request->input('v_prize');
        $vouchers->v_ex_date = $request->input('v_ex_date');
        $vouchers->t_can = $request->input('t_can');
        $vouchers->save();
        return redirect( '/vouch')->with('status', 'Data is update');

    }
    public function deletd(Request $request, $v_code)
    {
        $vouchers = voucher::findorFail($v_code);
        $vouchers->delete();
        return redirect('/vouch')->with('status', 'Data is Delete');

    }
}
