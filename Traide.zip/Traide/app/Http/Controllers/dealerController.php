<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class dealerController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function dealer()
    {

        $user=Auth::user();
        return view('dealer.bhome',compact('user'));

    }
}
