<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});




Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::post('/store_extra_details', 'HomeController@saveExtraDetail');

//Route::get('temp', function () {
//
//    \App\Models\UserType::query()->create([
//       'name' => 'Admin'
//    ]);
//
//});
                        // Admin route


Route::group(['middleware'=>['auth','3']],function (){


Route::get('/dashboard', function () {
    return view('admin.dashboard');
});

    Route::get('/users','userscontroller@users');


    Route::get('/user_edit/{id}','userscontroller@user_edit');

    Route::post('/user_update/{id}','userscontroller@user_update')->name('/user_update/{id}');

    Route::get('/user_delete/{id}','userscontroller@destroy')->name('/user_delete/{id}');

    Route::get('/vender','userscontroller@vender');

    Route::get('/buyers','userscontroller@buyers');

    Route::get('/dealer','userscontroller@dealer');

    Route::get('/products', function () {
        return view('admin.products');
    });
    Route::get('/products','userscontroller@products');
    Route::post('/saveproducts','userscontroller@save');
    Route::get('/products_edit/{p_code}','userscontroller@products_edit')->name('/products_edit/{p_code}');

    Route::post('/products_update/{p_code}','userscontroller@products_update')->name('/products_update/{p_code}');
    Route::get('/product_deleted/{p_code}','userscontroller@deleted')->name('/product_delete/{p_code}');



    Route::get('/vouchers', function () {
        return view('admin.vouchers');
    });
    Route::get('/vouchers','userscontroller@vouchers');
    Route::post('/savevouchers','userscontroller@savevouchers');
    Route::get('/vouchers_deleted/{v_code}','userscontroller@vouchersdeleted')->name('/vouchers_delete/{v_code}');
    Route::get('/vouchers_edits/{v_code}','userscontroller@vouchers_edits')->name('/vouchers_edits/{v_code}');
    Route::post('/vouchers_updates/{v_code}','userscontroller@vouchers_updates')->name('/vouchers_updates/{v_code}');


});
                              // byer route


Route::group(['middleware'=>['auth','2']],function () {

    Route::get('/bhome', function () {
        return view('byer.bhome');

    });

    Route::get('/voucard', function () {
        return view('byer.voucard');
    });


    if (Auth::check()){
        return view('byer.bhome','byercontroller@byer');
    }

    Route::get('/product', function () {
        return view('byer.product');
    });
    Route::get('/product','byercontroller@product');

    Route::get('/voucher', function () {
        return view('byer.voucher');
    });
    Route::get('/voucher','byercontroller@voucher');

    Route::get('/about_us', function () {
        return view('byer.aboutus');
    });
    Route::post('/savevoucher','byercontroller@savevoucher');
    Route::get('/voucher_delete/{v_code}','byercontroller@delete')->name('/voucher_delete/{v_code}');

    Route::get('/contact', function () {
        return view('byer.contact');
    });
});

             // Dealer route


Route::group(['middleware'=>['auth','1']],function () {

    Route::get('/dhome', function () {
        return view('dealer.dhome');
    });
    if (Auth::check()){
        return view('desler.bhome','dealercontroller@dealer');
    }
    Route::get('/about_us', function () {
        return view('byer.aboutus');
    });

});

// vender panel


Route::group(['middleware'=>['auth','4']],function (){


    Route::get('/vhome', function () {
        return view('vender.vhome');
    });
    Route::get('/about', function () {
        return view('vender.about');
    });
    Route::get('/prod', function () {
        return view('vender.prod');
    });
    Route::get('/prod','vendercontroller@prod');
    Route::post('/storeproducts','vendercontroller@store');
    Route::get('/product_delete/{p_code}','vendercontroller@delete')->name('/product_delete/{p_code}');


    Route::get('/vouch', function () {
        return view('vender.vouch');
    });
    Route::get('/vouch','vendercontroller@vouch');
    Route::post('/savevouch','vendercontroller@savevouch');
    Route::get('/vouch_delete/{v_code}','vendercontroller@deletd')->name('/vouch_delete/{v_code}');

    Route::get('/contus', function () {
        return view('vender.contus');
    });


});
