<?php $__env->startSection('title'); ?>
    User Edit|Form
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"> User Edit Form</h4>
                </div>

                <div class="card-body">

                        <?php if($errors->count() > 0): ?>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>

                    <form action="<?php echo e(route('/user_update/{id}',$users->id)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>


                        <div class="panel-body">
                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" class="form-control" name="name" id="name" placeholder="Name" value="<?php echo e($users->name); ?>">
                        </div>
                        <div class="form-group">
                            <label>Email address</label>
                            <input type="email" class="form-control" name="email" id="email" placeholder="Enter email">
                        </div>
                        <div class="form-group">
                            <label>Phone No</label>
                            <input type="tel" class="form-control" name="phone" id="phone" placeholder="Enter Phone no">
                        </div>

                            <button type="submit" class="btn btn-primary"> Update </button>



                             <a href="<?php echo e(url('/users')); ?>" class="btn btn-danger"> Cancle </a>

                        </div>
                    </form>

            </div>
        </div>
    </div>
    </div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts\master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\New folder\htdocs\Traide\resources\views/admin/user_edit.blade.php ENDPATH**/ ?>