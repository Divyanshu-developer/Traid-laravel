<?php $__env->startSection('title'); ?>
    User Edit|Form
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"> Products Edit Form</h4>
                </div>

                <div class="card-body">

                    <?php if($errors->count() > 0): ?>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>

                    <form action="<?php echo e(route('/products_update/{p_code}',$products->p_code)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>


                        <div class="panel-body">
                            <div class="form-group">
                                <label for="vander" class="col-form-label">Vender</label>
                                <input type="text" class="form-control" id="vander" name="vander">
                            </div>
                            <div class="form-group">
                                <label for="product" class="col-form-label">Product code</label>
                                <input type="text" class="form-control" id="p_code" name="p_code">
                            </div>
                            <div class="form-group">
                                <label for="productname" class="col-form-label">Product Name</label>
                                <input type="text" class="form-control" id="p_name"  name="p_name">
                            </div>
                            <div class="form-group">
                                <label for="productprize" class="col-form-label">Product price</label>
                                <input type="text" class="form-control" id="p_prize" name="p_prize">
                            </div>
                            <div class="form-group">
                                <label for="pdprize" class="col-form-label">Discount price</label>
                                <input type="text" class="form-control" id="pd_price" name="pd_price">
                            </div>
                            <div class="form-group">
                                <label for="message-text" class="col-form-label">Description</label>
                                <textarea class="form-control" id="message-text" name="description"></textarea>
                            </div>

                            <button type="submit" class="btn btn-primary"> Update </button>


                            <a href="<?php echo e(url('/products')); ?>" class="btn btn-danger"> Cancle </a>

                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts\master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\New folder\htdocs\Traide\resources\views/admin/productsedit.blade.php ENDPATH**/ ?>