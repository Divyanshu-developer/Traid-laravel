<!DOCTYPE html>
<html lang="en" xmlns:https="http://www.w3.org/1999/xhtml">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="public/assets/img/favicon.png">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title> <?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
        .btn {
            line-height: 40px;
            color: #fff;
            font-size: 14px;
            padding: 0;
            background: #010c38;
            padding: 0 36px;
            border: none;
        }

        .thankyou-section {
            padding: 100px 0;
            -webkit-box-shadow: 0px 22px 24px 0px rgba(0, 0, 0, 0.05);
            -moz-box-shadow: 0px 22px 24px 0px rgba(0, 0, 0, 0.05);
            box-shadow: 0px 22px 24px 0px rgba(0, 0, 0, 0.05);
        }

        .thankyou-section h2 {
            margin: 25px 0 15px;
            font-weight: 500;
            font-size: 48px;
            line-height: 36px;
            color: #091e5b;
        }

        .container{max-width:1200px;}

        h2{font-weight:700; color:#000080; text-transform:uppercase; font-size:45px; line-height:28px;}

        h3{font-weight:700; font-size: 22px;}

        .thankyou-section .inner-wrapper {
            max-width: 820px;
            margin: 0 auto;
        }
        .footer-widget .footer-widget-tit {
            color: #333;
            font-weight: 700;
            font-size: 18px;
            line-height: 18px;
            margin-bottom: 30px;
        }

        .widget-list{
            padding-left: 0;
            color: #333333;

        }
        .footer-section {
            text-align: left;

            padding: 80px 0 15px;
            display: block;
        }
        .footer-txt{
            text-align: center;
        }
        .social-widget .social-list {
            display: flex;
        }
        .justify-content-center {
            -ms-flex-pack: center !important;
            justify-content: center !important;
        }
        ul {
            list-style: none;
            list-style-position: initial;
            list-style-image: initial;
            list-style-type: none;
        }
        .social-list li {
            padding: 5px;
        }
        .thankyou-section .thankyou-form {
            display: flex;
            height: 46px;
        }

        .d-flex {
            display: -ms-flexbox;
            display: flex;
        }
    </style>
</head>
<body>
<div class="container-fluid">

    <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">

        <a href="https://www.tradvisor.in/public/">
            <img class="img-responsive" src="public/traide.png" alt="" style="height: 60px;" >
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Left Side Of Navbar -->
            <ul class="navbar-nav mr-auto">

            </ul>

            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ml-auto">
                <!-- Authentication Links -->
                <?php if(auth()->guard()->guest()): ?>
                    
                    
                    
                    
                    
                    
                    
                    
                <?php else: ?>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?php $userType = \App\Models\UserType::query()->where('id', '=', Auth::user()->user_type_id)->select('name')->first() ?>
                            <span class="badge badge-secondary"><?php echo e(isset($userType['name']) ? $userType['name'] : 'Role Not Defined'); ?></span>
                            <?php echo e(Auth::user()->name); ?>

                            #ID <?php echo e(Auth::user()->unique_id); ?>

                            <span class="caret"></span>
                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                <?php endif; ?>
            </ul>
        </div>


    </nav >
    <nav class="navbar navbar-expand-lg  bg-light">
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav" style="padding: 10px 0;
    color: #010417;
    font-weight: 700;
    text-transform: uppercase;
    font-size: 20px;
    line-height: 2; ">
            <li class="nav-item">
                <a class="nav-link " href="./vhome" style="color: #333366">Dashboard</a>
            </li>
            <li class="nav-item ">
                <a class="nav-link" href="./prod" style="color: #333366">Product</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="./vouch" style="color: #333366">Voucher</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="./about" style="color: #333366">About Us</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="./contus" style="color: #333366">Contact Us</a>
            </li>
        </ul>
        </div>
    </nav>
</div>


<div class="content">
    <?php echo $__env->yieldContent('content'); ?>

</div>

<?php echo $__env->yieldContent('scripts'); ?>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<section class="thankyou-section" >
    <div class="container">
        <div class="inner-wrapper">
            <div style="text-align:center">
                <img class="img-fluid mx-auto" src="https://www.tradvisor.in/public/front/images/smiley.png">
                <h2>Thank you!!</h2>
                <p>For giving your precious time to our site, We are here to help you.</p>
                <form class="thankyou-form d-flex" id="subscribe_form" name="subscribe_form" action="#">
                    <input type="text" name="subscribe_email" class="form-control  required-entry validate-email" placeholder="Enter your email here" style="margin: 0px;">
                    <button type="submit" id="home_subscribe" class="btn btn-primary">Subscribe</button>
                </form>
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-12 subscribe_error"></div>
                </div>
            </div>
        </div>
    </div>



</section>

<footer class="footer-section">
    <div class="wrapper">
        <div class="container">
            <div class="top-footer">
                <div class="row">
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12 mb-4 mb-sm-5 mb-lg-0">
                        <div class="footer-widget">
                            <h5 class="footer-widget-tit">Customer Services</h5>
                            <ul class="widget-list">
                                <li><a href="https://www.tradvisor.in/public/contact-us">Contact us</a></li>
                                <li><a href="https://www.tradvisor.in/public/career">Career</a></li>
                                <li><a href="https://www.tradvisor.in/public/aboutus">About Tradvisor</a></li>
                                <li><a href="https://www.tradvisor.in/public/cms/help-center">Help Center</a></li>
                                <li><a href="https://www.tradvisor.in/public/cms/privacy-policy">Privacy Policy</a></li>
                                <li><a href="https://www.tradvisor.in/public/cms/how-we-work">How we work</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12 mb-4 mb-sm-5 mb-lg-0">
                        <div class="footer-widget">
                            <h5 class="footer-widget-tit">About Us</h5>
                            <ul class="widget-list">
                                <li><a href="https://www.tradvisor.in/public/cms/our-team">Our Team</a></li>
                                <li><a href="https://www.tradvisor.in/public/cms/why-to-choose-tradvisor">Why to choose tradvisor?</a></li>
                                <li><a href="https://www.tradvisor.in/public/cms/faq">FAQ</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12 mb-4 mb-sm-0">
                        <div class="footer-widget">
                            <h5 class="footer-widget-tit">Buy on Tradvisor.in</h5>
                            <ul class="widget-list">

                                <li><a href="https://www.tradvisor.in/public/cms/sitemap">Sitemap</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <div class="footer-widget">
                            <h5 class="footer-widget-tit">Sell on Tradvisor.in</h5>
                            <ul class="widget-list">
                                <li><a href="https://www.tradvisor.in/public/subscription_plans">Supplier Memberships</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bottom-footer">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-12">
                            <div class="social-widget text-center">
                                <h5 class="footer-widget-tit pb-3" style="font-size: 25px;">Keep in touch</h5>

                                <ul class="social-list justify-content-center">

                                    <li><a target="_blank" href="https://www.instagram.com/tradvisor/"><img class="img-fluid" src="https://www.tradvisor.in/public/assets/images/icn-instagram.png" alt=""></a></li>

                                    <li><a target="_blank" href="https://twitter.com/tradvisor_in"><img class="img-fluid" src="https://www.tradvisor.in/public/assets/images/twitter.png" alt="" style="height: 45px;margin-top: -6px;"></a></li>


                                    <li><a target="_blank" href="https://www.youtube.com/channel/UC1KsEonHu9qyrCpLh9md-Yw"><img class="img-fluid" src="https://www.tradvisor.in/public/assets/images/icn-youtube.png" alt="" style="height: 42px;margin-top: -6px;"></a></li>
                                    <li><a target="_blank" href="https://www.facebook.com/TRADVISOR.IN/"><img class="img-fluid" src="https://www.tradvisor.in/public/assets/images/icn-facebook.png" alt=""></a></li>
                                    <li><a target="_blank" href="https://in.linkedin.com/company/tradvisor"><img class="img-fluid" src="https://www.tradvisor.in/public/assets/images/icn-linkedin.png" alt=""></a></li>

                                </ul>
                            </div>
                            <div class="footer-txt">
                                <p class="tradvisor-info"><span>Tradvisor.in :</span> Working on Domestic market in India, We are Best B2B trading website in India.</p>
                                <p class="links"><a href="https://www.tradvisor.in/public/cms/privacy-policy">Product Listing Policy</a> - <a href="https://www.tradvisor.in/public/cms/privacy-policy">Privacy Policy</a> - <a href="https://www.tradvisor.in/public/cms/our-team">Terms of Use</a></p>
                                <p class="copyright">© 2019 - 2029 Tradvisor.in. All rights reserved.</p>
                                <p class="design">Website Design &amp; Developed by: Tradvisor.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
</body>

</html>
<?php /**PATH E:\New folder\htdocs\Traide\resources\views/layouts/layut.blade.php ENDPATH**/ ?>