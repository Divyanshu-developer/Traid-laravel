<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div >
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title"> Dashboard</h4>
                            <?php if(session('status')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="card-body">

                            <h5>Name : <?php echo e(Auth::user()->name); ?></h5>
                            <h5>Email : <?php echo e(Auth::user()->email); ?> </h5>
                            <h5>Phone no : <?php echo e(Auth::user()->phone); ?></h5>
                            <h5>Unique id : <?php echo e(Auth::user()->unique_id); ?></h5>


                        </div>

                        
                        
                        
                        

                        
                        
                        
                        
                        
                        
                        
                        
                        
                        

                        
                        
                        
                        
                        
                        
                        
                        

                        
                        
                        

                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layut', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\New folder\htdocs\Traide\resources\views/vender/vhome.blade.php ENDPATH**/ ?>