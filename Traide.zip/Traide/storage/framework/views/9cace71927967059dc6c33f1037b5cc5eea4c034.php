<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"> Dashboard</h4>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="row">
                <div class="card-body" style="padding: 50px; ">

                    <h5>Name :      <?php echo e(Auth::user()->name); ?></h5>&nbsp;
                    <h5>Email :     <?php echo e(Auth::user()->email); ?> </h5>&nbsp;
                    <h5>Phone no :  <?php echo e(Auth::user()->phone); ?></h5>&nbsp;
                    <h5>Unique id : <?php echo e(Auth::user()->unique_id); ?></h5>
                </div>
                </div>






























            </div>
        </div>
    </div>
    </div>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.lyout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\New folder\htdocs\Traide\resources\views/byer/bhome.blade.php ENDPATH**/ ?>