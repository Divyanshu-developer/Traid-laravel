<?php $__env->startSection('title'); ?>
    Admin Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"> Users Table</h4>
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead class=" text-primary">
                            <th>Name</th>
                            <th>Email id</th>
                            <th>Phone</th>
                            <th>Unique_id</th>
                            <th>User_type_id</th>
                            </thead>
                            <tbody>
                            <tr>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($row->name); ?></td>
                                <td><?php echo e($row->phone); ?></td>
                                <td><?php echo e($row->emailinique_id); ?></td>
                                <td><?php echo e($row->user_type_id); ?></td>

                                <td>
                                    <a href="#" class="btn btn-success">Edit</a>
                                </td>
                                <td>
                                    <a href="#" class="btn btn-danger">Delete</a>
                                </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\New folder\htdocs\Traide\resources\views/admin/ausers.blade.php ENDPATH**/ ?>