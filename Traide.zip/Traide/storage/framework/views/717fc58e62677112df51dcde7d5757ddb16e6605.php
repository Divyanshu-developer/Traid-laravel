<?php $__env->startSection('title'); ?>
User Edit|Form
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title"> Voucher Edit Form</h4>
            </div>

            <div class="card-body">

                <?php if($errors->count() > 0): ?>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php endif; ?>

                <form action="<?php echo e(route('/vouchers_updates/{v_code}', $vouchers->v_code)); ?>" method="post">
                    <?php echo e(csrf_field()); ?>


                    <div class="panel-body">

                            <div class="form-group">
                                <label for="v_code" class="col-form-label">Voucher code</label>
                                <input type="text" class="form-control" id="v_code" name="v_code">
                            </div>
                            <div class="form-group">
                                <label for="v_name" class="col-form-label">Voucher Name</label>
                                <input type="text" class="form-control" id="v_name"  name="v_name">
                            </div>
                            <div class="form-group">
                                <label for="v_prize" class="col-form-label">Voucher price</label>
                                <input type="text" class="form-control" id="v_prize" name="v_prize">
                            </div>
                            <div class="form-group">
                                <label for="v_ex_date" class="col-form-label">Voucher Ex.Date</label>
                                <input type="date" class="form-control" id="v_ex_date" name="v_ex_date">
                            </div>
                            <div class="form-group">
                                <label for="t&c" class="col-form-label">Voucher T&C</label>
                                <input type="text" class="form-control" id="t_can" name="t_can">
                            </div>


                        <button type="submit" class="btn btn-primary"> Update </button>


                        <a href="<?php echo e(url('/vouchers')); ?>" class="btn btn-danger"> Cancle </a>

                    </div>
                </form>

            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts\master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\New folder\htdocs\Traide\resources\views/admin/vouchers_edits.blade.php ENDPATH**/ ?>