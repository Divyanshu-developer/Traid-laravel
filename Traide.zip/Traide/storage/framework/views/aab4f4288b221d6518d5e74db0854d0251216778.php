<?php $__env->startSection('title'); ?>
    Voucher
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
        <div class="card-columns" style="padding: 70px">
            <div class="card bg-dark">
                <div class="card-body text-center" style="padding: 20px; margin: 50px; color: #fdfdfe;" >
                    <p class="card-text" >Food Voucher</p>
                    <a href="<?php echo e(url('/voucher')); ?>">VOUCHERS</a>

                </div>
            </div>

            <div class="card bg-dark">
                <div class="card-body text-center" style="padding: 20px; margin: 50px; color: #fdfdfe;" >
                    <p class="card-text">Clothes Voucher</p>
                    <a href="<?php echo e(url('/voucher')); ?>">VOUCHERS</a>
                </div>
            </div>

            <div class="card bg-dark">
                <div class="card-body text-center" style="padding: 20px; margin: 50px; color: #fdfdfe;" >
                    <p class="card-text">Shoes Voucher</p>
                    <a href="<?php echo e(url('/voucher')); ?>">VOUCHERS</a>
                </div>
            </div>

            <div class="card bg-dark">
                <div class="card-body text-center" style="padding: 20px; margin: 50px; color: #fdfdfe;" >
                    <p class="card-text">Watch Voucher</p>
                    <a href="<?php echo e(url('/voucher')); ?>">VOUCHERS</a>
                </div>
            </div>

            <div class="card bg-dark">
                <div class="card-body text-center" style="padding: 20px; margin: 50px; color: #fdfdfe;" >
                    <p class="card-text">Movie Voucher</p>
                    <a href="<?php echo e(url('/voucher')); ?>">VOUCHERS</a>
                </div>
            </div>

            <div class="card bg-dark">
                <div class="card-body text-center" style="padding: 20px; margin: 50px; color: #fdfdfe;" >
                    <p class="card-text">Vehical Voucher</p>
                    <a href="<?php echo e(url('/voucher')); ?>">VOUCHERS</a>
                </div>
            </div>
        </div>
    </div>
                </div>
            </div>
        </div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.lyout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\New folder\htdocs\Traide\resources\views/byer/voucard.blade.php ENDPATH**/ ?>