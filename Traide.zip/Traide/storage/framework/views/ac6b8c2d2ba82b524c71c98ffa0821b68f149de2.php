Hi <strong><?php echo e($name); ?></strong>,

<p><?php echo e($body); ?></p>
<?php /**PATH E:\New folder\htdocs\Traide\resources\views/byer/mail.blade.php ENDPATH**/ ?>