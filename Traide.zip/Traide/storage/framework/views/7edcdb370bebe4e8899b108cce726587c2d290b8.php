<?php $__env->startSection('title'); ?>
    About Us
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
    .all_section_heading{
        margin: 40px 0 20px;
        font-weight: 500;
        font-size: 48px;
        line-height: 36px;


    }
</style>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">

    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section_heading text-center">
                    <h2 class="all_section_heading">Advantage through Tradvisor</h2>
                    <div><i class="mbri-more-horizontal all_section_icons  text_custom font-weight-bold">&nbsp;</i></div>
                    <p class="text-muted pt-2 all_section_heading_details text-center mx-auto">At Tradvisor, we have designed the platform to not only enhance the business proficiency of various companies but also give them sufficient space to establish their network across India.</p>
                </div>
            </div>
        </div>
        <div class="row mt-5 equal">
            <div class="col-lg-6 cbcollg6">
                <div class="faq_contant p-4 mt-3 bg-light">
                    <h3 class="font-weight-bold text-uppercase">Find relevant customers and suppliers</h3>
                    <p class="mb-0 text-muted">♦ Find out and discover customers, suppliers and products across numerous categories pan India. <br>♦ Option to Filter data on the basis of Pricing, Geographically, Availability of Material and HSN Code.</p>
                </div>
            </div>
            <div class="col-lg-6 cbcollg6">
                <div class="faq_contant p-4 mt-3 bg-light">
                    <h3 class="font-weight-bold text-uppercase">Connect with market</h3>
                    <p class="mb-0 text-muted">♦ Helps to connect market directly that facilitates trade between entities verified by Tradvisor.</p>
                </div>
            </div>
        </div>
        <div class="row mt-3 equal">
            <div class="col-lg-6 cbcollg6">
                <div class="faq_contant p-4 mt-3 bg-light">
                    <h3 class="font-weight-bold text-uppercase">liquidate static inventory</h3>
                    <p class="mb-0 text-muted">♦ Opportunity to liquidate dead/non-moving inventory and fixed assets.</p>
                </div>
            </div>
            <div class="col-lg-6 cbcollg6">
                <div class="faq_contant p-4 mt-3 bg-light">
                    <h3 class="font-weight-bold text-uppercase">Quotations</h3>
                    <p class="mb-0 text-muted">♦ Invite quotes for your input needs and Offer quotes for your finished/ Trading products.</p>
                </div>
            </div>
        </div>
        <div class="row mt-3 equal">
            <div class="col-lg-6 cbcollg6">
                <div class="faq_contant p-4 mt-3 bg-light">
                    <h3 class="font-weight-bold text-uppercase">Branding/Advertisement</h3>
                    <p class="mb-0 text-muted">♦ We offer an opportunity to expand your business horizons by advertising and branding your products with Tradvisor.</p>
                </div>
            </div>
            <div class="col-lg-6 cbcollg6">
                <div class="faq_contant p-4 mt-3 bg-light">
                    <h3 class="font-weight-bold text-uppercase">Infinite Growth:</h3>
                    <p class="mb-0 text-muted">♦ Now grow your network presence and business. Expand beyond your reach.</p>
                </div>
            </div>
        </div>
    </div>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.lyout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\New folder\htdocs\Traide\resources\views/byer/aboutus.blade.php ENDPATH**/ ?>