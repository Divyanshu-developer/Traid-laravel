<?php $__env->startSection('title'); ?>
    Voucher
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add New Products</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(url('savevouchers')); ?>" method="post">
                <div class="modal-body">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="v_code" class="col-form-label">Voucher code</label>
                            <input type="text" class="form-control" id="v_code" name="v_code">
                        </div>
                        <div class="form-group">
                            <label for="v_name" class="col-form-label">Voucher Name</label>
                            <input type="text" class="form-control" id="v_name"  name="v_name">
                        </div>
                        <div class="form-group">
                            <label for="v_prize" class="col-form-label">Voucher price</label>
                            <input type="text" class="form-control" id="v_prize" name="v_prize">
                        </div>
                        <div class="form-group">
                            <label for="v_ex_date" class="col-form-label">Voucher Ex.Date</label>
                            <input type="date" class="form-control" id="v_ex_date" name="v_ex_date">
                        </div>
                        <div class="form-group">
                             <label for="t&c" class="col-form-label">Voucher T&C</label>
                             <input type="text" class="form-control" id="t_can" name="t_can">
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
                </form>
            </div>
        </div>
    </div>

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <h4 class="card-title"> Voucher Table</h4>
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" >Add</button>
                    </div>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead class=" text-primary">
                                <th>
                                    Voucher code
                                </th>
                                <th>
                                    Voucher Name
                                </th>
                                <th>
                                    Voucher Prize
                                </th>
                                <th>
                                    Voucher Ex.Date
                                </th>
                                <th>
                                    Voucher T&C
                                </th>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>

                                        <td><?php echo e($voucher->v_code); ?></td>
                                        <td><?php echo e($voucher->v_name); ?></td>
                                        <td><?php echo e($voucher->v_prize); ?></td>
                                        <td><?php echo e($voucher->v_ex_date); ?></td>
                                        <td><?php echo e($voucher->t_can); ?></td>
                                        <td>
                                            <a href="<?php echo e(url('/vouchers_edits/'.$voucher->v_code)); ?>" class="btn btn-success">Edit</a>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(url('/vouchers_deleted/'.$voucher->v_code)); ?>" class="btn btn-danger"> Delete </a>

                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\New folder\htdocs\Traide\resources\views/admin/vouchers.blade.php ENDPATH**/ ?>