<?php $__env->startSection('title'); ?>
    Voucher
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <h4 class="card-title"> Voucher Table</h4>
                    </div>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead class=" text-primary">
                                <th>
                                    Voucher code
                                </th>
                                <th>
                                    Voucher Name
                                </th>
                                <th>
                                    Voucher Price
                                </th>
                                <th>
                                    Voucher Ex.Date
                                </th>
                                <th>
                                    Voucher T&C
                                </th>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $voucher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>

                                        <td><?php echo e($voucher->v_code); ?></td>
                                        <td><?php echo e($voucher->v_name); ?></td>
                                        <td><?php echo e($voucher->v_prize); ?></td>
                                        <td><?php echo e($voucher->v_ex_date); ?></td>
                                        <td><?php echo e($voucher->t_can); ?></td>
                                        <?php if(Auth::user()->user_type_id == 2): ?>
                                        <td> <div class="check">
                                                <input class="form-check-input position-static" type="checkbox" id="blankCheckbox" value="option1" aria-label="...">
                                            </div></td>
                                        <td>  <a href="<?php echo e(url('$/voucher/'.$voucher->v_code)); ?>" class="btn btn-success">Submit</a></td>
                                        <?php endif; ?>
                                    </tr>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.lyout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\New folder\htdocs\Traide\resources\views/byer/voucher.blade.php ENDPATH**/ ?>