<?php


class Auth
{

    public static function user()
    {
    }
}
