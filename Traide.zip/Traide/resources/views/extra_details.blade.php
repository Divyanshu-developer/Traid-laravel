@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12  ">
            <div class="card">
                <div class="card-header">
                    <div class="card-text">Fill Your Details To Activate Your Account</div>
                </div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                        <form method="post" action="{{ url('store_extra_details') }}">
                            @csrf
                            <div>
                                <div class="form-group">


                                    <div class="form-group">
                                        <label for="aadharno">{{__('Aadhar No.')}}</label>
                                        <input id="aadharno" type="tel"
                                               class="form-control @error('aadharno') is-invalid @enderror"
                                               name="aadharno" value="{{old('aadharno')}}" required
                                               autocomplete="aadharno"/> @error('aadharno')
                                        <span class="invalid-feedback" role="alert"> <strong>{{$message}}</strong> </span> @enderror
                                    </div>

                                    <div class="form-group">
                                        <label for="inputpan ">Pan Card No.</label> <input type="text"
                                                                                           class="form-control @error('panno') is-invalid @enderror"
                                                                                           name="panno"
                                                                                           value="{{old('panno')}}"
                                                                                           required
                                                                                           autocomplete="panno"/> @error('panno')
                                        <span class="invalid-feedback" role="alert"> <strong>{{$message}}</strong> </span> @enderror
                                    </div>
                                    <div class="form-group">
                                        <label for="inputDOB4">Date of Birth</label> <input type="date"
                                                                                            class="form-control @error('dob') is-invalid @enderror"
                                                                                            name="dob"
                                                                                            value="{{old('dob')}}"
                                                                                            required
                                                                                            autocomplete="dob"/> @error('dob')
                                        <span class="invalid-feedback" role="alert"> <strong>{{$message}}</strong> </span> @enderror
                                    </div>
                                    <div class="form-group">
                                        <p>Gender</p>
                                        <div class="custom-control custom-radio custom-control-inline">
                                            <input type="radio" id="customRadioInline1" name="gender" value="1"
                                                   class="custom-control-input @error('gender') is-invalid @enderror"
                                                   required checked autocomplete="male"/>
                                            <label class="custom-control-label"
                                                   for="customRadioInline1">Male</label>
                                        </div>
                                        <div class="custom-control custom-radio custom-control-inline">
                                            <input type="radio" id="customRadioInline2" name="gender" value="2"
                                                   class="custom-control-input @error('gender') is-invalid @enderror"
                                                   required autocomplete="female"/>
                                            <label class="custom-control-label"
                                                   for="customRadioInline2">Female</label>
                                        </div>
                                        @error('gender') <span class="invalid-feedback"
                                                               role="alert"> <strong>{{$message}}</strong> </span> @enderror
                                    </div>
                                    <div class="form-group">
                                        <label for="inputAddress">Address</label>
                                        <input type="text" id="inputAddress" placeholder="1234 Main St"
                                               name="address"
                                               class="form-control @error('address') is-invalid @enderror"
                                               value="{{old('address')}}" required autocomplete="address"/>
                                        @error('address') <span class="invalid-feedback"
                                                                role="alert"> <strong>{{$message}}</strong> </span> @enderror
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label for="inputCity">City</label>
                                            <div class="form-group">
                                                <select class="form-control" id="inputCity" name="city_id">
                                                    @php $cities = \App\Models\City::query()->orderBy('city')->get()->toArray() @endphp
                                                    @foreach($cities as $city)
                                                        <option value="{{ $city['id'] }}">{{ $city['city'] }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            @error('city')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{$message}}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="inputZip">Zip</label>
                                            <input type="tel" id="inputZip" placeholder="Zip" name="zip"
                                                   class="form-control @error('zip') is-invalid @enderror"
                                                   value="{{old('zip')}}" required autocomplete="zip"/> @error('zip')
                                            <span class="invalid-feedback"
                                                  role="alert"> <strong>{{$message}}</strong> </span> @enderror
                                        </div>
                                    </div>


                                        @if(Auth::user()->user_type_id == 2)
                                            <div class="form-group">
                                                <label for="dealer_id">{{__('Dealer Code')}}  </label>
                                                <input id="dealer_id" type="tel"
                                                       class="form-control @error('dealer_id') is-invalid @enderror"
                                                       name="dealer_id" value="{{old('dealer_id')}}" required
                                                       autocomplete="dealer_id" autofocus/> @error('dealer_id')
                                                <span class="invalid-feedback" role="alert"> <strong>{{$message}}</strong> </span> @enderror
                                            </div>
                                        @endif


                                    <div class="form-group">
                                        <div class="form-check">
                                            <input class="form-check-input" onclick="btnUpdate();" type="checkbox" value=""
                                                   id="invalidCheck" required/> <label class="form-check-label"
                                                                                       for="invalidCheck"> Agree to
                                                terms and conditions </label>
                                            <div class="invalid-feedback">You must agree before submitting.</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 m-0 p-0">
                                    <button type="submit" id="submit" class="btn btn-primary btn-block" disabled>Submit</button>
                                </div>
                            </div>
                        </form>


                </div>
            </div>
        </div>
    </div>
</div>
<script>
    function btnUpdate() {
        const element = document.getElementById("invalidCheck");
        document.getElementById("submit").disabled = !element.checked;
    }
</script>
@endsection
