Hi <strong>{{ $name }}</strong>,

<p>{{ $body }}</p>
