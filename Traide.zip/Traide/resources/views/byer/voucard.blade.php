@extends('layouts.lyout')


@section('title')
    Voucher
@endsection

@section('content')
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
        <div class="card-columns" style="padding: 70px">
            <div class="card bg-dark">
                <div class="card-body text-center" style="padding: 20px; margin: 50px; color: #fdfdfe;" >
                    <p class="card-text" >Food Voucher</p>
                    <a href="{{url('/voucher')}}">VOUCHERS</a>

                </div>
            </div>

            <div class="card bg-dark">
                <div class="card-body text-center" style="padding: 20px; margin: 50px; color: #fdfdfe;" >
                    <p class="card-text">Clothes Voucher</p>
                    <a href="{{url('/voucher')}}">VOUCHERS</a>
                </div>
            </div>

            <div class="card bg-dark">
                <div class="card-body text-center" style="padding: 20px; margin: 50px; color: #fdfdfe;" >
                    <p class="card-text">Shoes Voucher</p>
                    <a href="{{url('/voucher')}}">VOUCHERS</a>
                </div>
            </div>

            <div class="card bg-dark">
                <div class="card-body text-center" style="padding: 20px; margin: 50px; color: #fdfdfe;" >
                    <p class="card-text">Watch Voucher</p>
                    <a href="{{url('/voucher')}}">VOUCHERS</a>
                </div>
            </div>

            <div class="card bg-dark">
                <div class="card-body text-center" style="padding: 20px; margin: 50px; color: #fdfdfe;" >
                    <p class="card-text">Movie Voucher</p>
                    <a href="{{url('/voucher')}}">VOUCHERS</a>
                </div>
            </div>

            <div class="card bg-dark">
                <div class="card-body text-center" style="padding: 20px; margin: 50px; color: #fdfdfe;" >
                    <p class="card-text">Vehical Voucher</p>
                    <a href="{{url('/voucher')}}">VOUCHERS</a>
                </div>
            </div>
        </div>
    </div>
                </div>
            </div>
        </div>


@endsection


@section('scripts')

@endsection
