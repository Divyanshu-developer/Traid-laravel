@extends('layouts.lyout')


@section('title')
    Voucher
@endsection

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif
                        <h4 class="card-title"> Voucher Table</h4>
                    </div>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead class=" text-primary">
                                <th>
                                    Voucher code
                                </th>
                                <th>
                                    Voucher Name
                                </th>
                                <th>
                                    Voucher Price
                                </th>
                                <th>
                                    Voucher Ex.Date
                                </th>
                                <th>
                                    Voucher T&C
                                </th>
                                </thead>
                                <tbody>
                                @foreach($voucher as $voucher)
                                    <tr>

                                        <td>{{$voucher->v_code}}</td>
                                        <td>{{$voucher->v_name}}</td>
                                        <td>{{$voucher->v_prize}}</td>
                                        <td>{{$voucher->v_ex_date}}</td>
                                        <td>{{$voucher->t_can}}</td>
                                        @if(Auth::user()->user_type_id == 2)
                                        <td> <div class="check">
                                                <input class="form-check-input position-static" type="checkbox" id="blankCheckbox" value="option1" aria-label="...">
                                            </div></td>
                                        <td>  <a href="{{url('$/voucher/'.$voucher->v_code)}}" class="btn btn-success">Submit</a></td>
                                        @endif
                                    </tr>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

@endsection


@section('scripts')

@endsection
