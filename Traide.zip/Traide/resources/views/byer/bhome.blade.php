@extends('layouts.lyout')

@section('title')
    Home
@endsection

@section('content')

    <div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"> Dashboard</h4>
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                <div class="card-body" style="padding: 50px; ">

                    <h5>Name :      {{Auth::user()->name}}</h5>&nbsp;
                    <h5>Email :     {{Auth::user()->email}} </h5>&nbsp;
                    <h5>Phone no :  {{Auth::user()->phone}}</h5>&nbsp;
                    <h5>Unique id : {{Auth::user()->unique_id}}</h5>
                </div>
                </div>

{{--                <div class="card-body">--}}
{{--                    <div class="table-responsive">--}}
{{--                        <table class="table">--}}
{{--                            <thead class="text">--}}

{{--                            <th>Name</th>--}}
{{--                            <th>Email id</th>--}}
{{--                            <th>Phone</th>--}}
{{--                            <th>Unique_id</th>--}}
{{--                            <th>User_type_id</th>--}}
{{--                            --}}
{{--                            </thead>--}}
{{--                            <tbody>--}}
{{--                            @foreach($user as $row)--}}
{{--                                <tr>--}}

{{--                                    <td>{{Auth::user()->name}}</td>--}}
{{--                                    <td>{{Auth::user()->email}}</td>--}}
{{--                                    <td>{{Auth::user()->phone}}</td>--}}
{{--                                    <td>{{Auth::user()->unique_id}}</td>--}}
{{--                                    <td>{{Auth::user()->user_type_id}}</td>--}}
{{--                                </tr>--}}
{{--                            @endforeach--}}
{{--                            </tbody>--}}

{{--                        </table>--}}
{{--                    </div>--}}
{{--                </div>--}}

            </div>
        </div>
    </div>
    </div>



@endsection


@section('scripts')

@endsection
