@extends('layouts.layut')


@section('title')
    Product
@endsection

@section('content')
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add New Products</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="{{ url('storeproducts')}}" method="post">
                    <div class="modal-body">
                        {{csrf_field()}}
                        <div class="form-group">
                            <label for="vender" class="col-form-label">Vender</label>
                            <input type="text" class="form-control" id="vender" name="vander">
                        </div>
                        <div class="form-group">
                            <label for="product" class="col-form-label">Product code</label>
                            <input type="text" class="form-control" id="p_code" name="p_code">
                        </div>
                        <div class="form-group">
                            <label for="productname" class="col-form-label">Product Name</label>
                            <input type="text" class="form-control" id="p_name"  name="p_name">
                        </div>
                        <div class="form-group">
                            <label for="productprize" class="col-form-label">Product prize</label>
                            <input type="text" class="form-control" id="p_prize" name="p_prize">
                        </div>
                        <div class="form-group">
                            <label for="pdprize" class="col-form-label">Discount prize</label>
                            <input type="text" class="form-control" id="pd_price" name="pd_price">
                        </div>
                        <div class="form-group">
                            <label for="message-text" class="col-form-label">Description</label>
{{--                            <input type="text" class="form-control" id="message-text" name="description">--}}
                            <textarea class="form-control" id="message-text" name="description"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>




    {{--    End mpdel--}}
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif
                        <h4 class="card-title"> Product Table</h4>
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" >Add</button>
                    </div>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead class=" text-primary">
                                <th>
                                    Vendor
                                </th>
                                <th>
                                    Product code
                                </th>
                                <th>
                                    Product Name
                                </th>
                                <th>
                                    Product Price
                                </th>
                                <th>
                                    Discount Price
                                </th>
                                <th>
                                    Description
                                </th>

                                </thead>
                                <tbody>

                                @foreach($products as $product)
                                    <tr>
                                        <td>{{$product->vander}}</td>
                                        <td>{{$product->p_code}}</td>
                                        <td>{{$product->p_name}}</td>
                                        <td>{{$product->p_prize}}</td>
                                        <td>{{$product->pd_price}}</td>
                                        <td>{{$product->description}}</td>
                                        <td>
                                            <a href="{{url('/product_edit/')}}" class="btn btn-success">Edit</a>
                                        </td>
                                        <td>
                                            <form action="/product_delete/{{$product->p_code}}" method="get">
                                                {{csrf_field()}}
                                                <a href="{{ url('/product_delete/'.$product->p_code) }}" class="btn btn-danger"> Delete </a>
                                            </form>
                                        </td>
                                    </tr>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

@endsection


@section('scripts')

@endsection
