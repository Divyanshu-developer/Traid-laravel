@extends('layouts.layut')

@section('title')
    Contact Us
@endsection

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
    <section class="inner-content-section" style="padding: 50px;">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12" style="padding: 0px;">
                    <form action="https://www.tradvisor.in/public/contact-us/add" id="contactform-validate" method="post" name="contactform-validate" class="registration-form" novalidate="novalidate" style="background: #e6e8f0;padding: 40px 60px;text-align: left;height: auto;">
                        <input type="hidden" name="_token" value="kiMBqmvnN4vq9tyHINWcXld2PI6msgym3OY5OGn2">            <div class="form-btm-part">
                            <div class="row">
                                <div class="col-md-12" >
                                    <div class="form-group form-float">
                                        <div class="form-line">
                                            <label class="form-label" style="font-size: 20px;color: #08022b; line-height: 16px;">Name<span style="color: red;">*</span></label>
                                            <input placeholder="Name" class="form-control required-entry" id="name" name="name" type="text" required="" aria-required="true" style=" border: 1px solid #4c5b87; line-height: 40px;font-size: 20px;  ">
                                        </div>
                                    </div>
                                </div>
                                &nbsp;
                                <div class="col-md-12">
                                    <div class="form-group form-float">
                                        <div class="form-line">
                                            <label class="form-label" style="font-size: 20px;color: #08022b; line-height: 16px;">Email<span style="color: red;">*</span></label>
                                            <input placeholder="Email" class="form-control required-entry validate-email" id="email" name="email" type="text" required="" aria-required="true" style=" border: 1px solid #4c5b87; line-height: 40px;font-size: 20px;">
                                        </div>
                                    </div>
                                </div>
                                &nbsp;
                                <div class="col-md-12">
                                    <div class="form-group form-float">
                                        <div class="form-line">
                                            <label class="form-label" style="font-size: 20px;color: #08022b; line-height: 16px;">Contact Number<span style="color: red;">*</span></label>
                                            <input placeholder="Contact Number" class="form-control required-entry" name="phone" type="text" autocomplete="off" required="" onkeyup="if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')" aria-required="true" style=" border: 1px solid #4c5b87; line-height: 40px;font-size: 20px;">
                                        </div>
                                    </div>
                                </div>
                                &nbsp;
                                <div class="col-md-12">
                                    <div class="form-group form-float">
                                        <div class="form-line">
                                            <label class="form-label" style="font-size: 20px;color: #08022b; line-height: 16px;">Address<span style="color: red;">*</span></label>
                                            <textarea placeholder="Address" class="form-control required-entry" id="address" name="address" rows="2" required="" aria-required="true" style=" border: 1px solid #4c5b87; line-height: 40px;font-size: 20px;"></textarea>
                                        </div>
                                    </div>
                                </div>
                                &nbsp;
                                <div class="col-md-12">
                                    <div class="form-group form-float">
                                        <div class="form-line">
                                            <label class="form-label" style="font-size: 20px;color: #08022b; line-height: 16px;">Message<span style="color: red;">*</span></label>
                                            <textarea placeholder="Message" class="form-control required-entry" id="message" name="message" rows="4" required="" aria-required="true" style=" border: 1px solid #4c5b87; line-height: 40px;font-size: 20px;"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            &nbsp;
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group form-float" >
                                        <input class="btn btn_custom" type="submit" value="Send Message" style="line-height: 58px;font-size: 20px;">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12"  style="padding: 0px; ">
                    <div class="row" style="margin-left:10px !important;">
                        <div class="col-md-12" >

                            <div class="text-center mt-3 display-flex" style="border: 1px solid #020c38;padding: 15px;font-size: 16px;">
                                <div class="contact_icon" style="color: #6c757d !important;"><svg width="1.5em" height="2em" viewBox="0 0 16 16" class="bi bi-geo-alt" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10zm0-7a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
                                    </svg></div>
                                <div class="mt-2 margin-top-7">
                                    <p class="mb-0 font-weight-bold" style="color: #6c757d !important; font-size: 20px;"><strong>Address</strong></p>
                                    <p class="text-muted" style="color: #6c757d !important; font-size: 20px;">A/103-105, Samudra Complex, Girish Cold Drinks Cross Road, C.G. Road, Ahmedabad-380009.</p>
                                </div>
                            </div>

                            <div class="text-center mt-3 display-flex" style="border: 1px solid #020c38;padding: 15px;font-size: 16px;">
                                <div class="contact_icon" style="color: #6c757d !important;"><svg width="1.5em" height="2em" viewBox="0 0 16 16" class="bi bi-telephone-fill" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" d="M2.267.98a1.636 1.636 0 0 1 2.448.152l1.681 2.162c.309.396.418.913.296 1.4l-.513 2.053a.636.636 0 0 0 .167.604L8.65 9.654a.636.636 0 0 0 .604.167l2.052-.513a1.636 1.636 0 0 1 1.401.296l2.162 1.681c.777.604.849 1.753.153 2.448l-.97.97c-.693.693-1.73.998-2.697.658a17.47 17.47 0 0 1-6.571-4.144A17.47 17.47 0 0 1 .639 4.646c-.34-.967-.035-2.004.658-2.698l.97-.969z"/>
                                    </svg></div>
                                <div class="mt-2 margin-top-7">
                                    <p class="mb-0 font-weight-bold" style="color: #6c757d !important; font-size: 20px;"><strong>Call Us</strong></p>
                                    <p class="mb-0 font-weight-bold">
                                        <a href="tell:+91 79480 58888" style="background: transparent;color: #51619f; font-size: 20px;">+91 79480 58888</a>
                                    </p>
                                </div>
                            </div>
                            <div class="text-center mt-3 display-flex" style="border: 1px solid #020c38;padding: 15px;font-size: 16px;">
                                <div class="contact_icon" style="color: #6c757d !important;"><svg width="1.5em" height="2em" viewBox="0 0 16 16" class="bi bi-envelope-fill" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" d="M.05 3.555A2 2 0 0 1 2 2h12a2 2 0 0 1 1.95 1.555L8 8.414.05 3.555zM0 4.697v7.104l5.803-3.558L0 4.697zM6.761 8.83l-6.57 4.027A2 2 0 0 0 2 14h12a2 2 0 0 0 1.808-1.144l-6.57-4.027L8 9.586l-1.239-.757zm3.436-.586L16 11.801V4.697l-5.803 3.546z"/>
                                    </svg></div>
                                <div class="mt-2 margin-top-7">
                                    <p class="mb-0 font-weight-bold" style="color: #6c757d !important; font-size: 20px;"><strong>For Support Enquiries</strong></p>
                                    <p class="text-muted"><a href="mailto:support@tradvisor.in" style="background: transparent;color: #51619f; font-size: 20px;">support@tradvisor.in</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
                </div>
            </div>
        </div>
    </div>
@endsection


@section('scripts')

@endsection
