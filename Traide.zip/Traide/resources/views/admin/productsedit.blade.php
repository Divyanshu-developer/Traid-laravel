@extends('layouts\master')


@section('title')
    User Edit|Form
@endsection

@section('content')

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"> Products Edit Form</h4>
                </div>

                <div class="card-body">

                    @if ($errors->count() > 0)
                        <ul>
                            @foreach($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    @endif

                    <form action="{{ route('/products_update/{p_code}',$products->p_code)}}" method="post">
                        {{ csrf_field() }}

                        <div class="panel-body">
                            <div class="form-group">
                                <label for="vander" class="col-form-label">Vender</label>
                                <input type="text" class="form-control" id="vander" name="vander">
                            </div>
                            <div class="form-group">
                                <label for="product" class="col-form-label">Product code</label>
                                <input type="text" class="form-control" id="p_code" name="p_code">
                            </div>
                            <div class="form-group">
                                <label for="productname" class="col-form-label">Product Name</label>
                                <input type="text" class="form-control" id="p_name"  name="p_name">
                            </div>
                            <div class="form-group">
                                <label for="productprize" class="col-form-label">Product price</label>
                                <input type="text" class="form-control" id="p_prize" name="p_prize">
                            </div>
                            <div class="form-group">
                                <label for="pdprize" class="col-form-label">Discount price</label>
                                <input type="text" class="form-control" id="pd_price" name="pd_price">
                            </div>
                            <div class="form-group">
                                <label for="message-text" class="col-form-label">Description</label>
                                <textarea class="form-control" id="message-text" name="description"></textarea>
                            </div>

                            <button type="submit" class="btn btn-primary"> Update </button>


                            <a href="{{ url('/products')}}" class="btn btn-danger"> Cancle </a>

                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>


@endsection


@section('scripts')

@endsection
