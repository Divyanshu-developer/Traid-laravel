@extends('layouts\master')


@section('title')
User Edit|Form
@endsection

@section('content')

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title"> Voucher Edit Form</h4>
            </div>

            <div class="card-body">

                @if ($errors->count() > 0)
                <ul>
                    @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                    @endforeach
                </ul>
                @endif

                <form action="{{ route('/vouchers_updates/{v_code}', $vouchers->v_code)}}" method="post">
                    {{ csrf_field() }}

                    <div class="panel-body">

                            <div class="form-group">
                                <label for="v_code" class="col-form-label">Voucher code</label>
                                <input type="text" class="form-control" id="v_code" name="v_code">
                            </div>
                            <div class="form-group">
                                <label for="v_name" class="col-form-label">Voucher Name</label>
                                <input type="text" class="form-control" id="v_name"  name="v_name">
                            </div>
                            <div class="form-group">
                                <label for="v_prize" class="col-form-label">Voucher price</label>
                                <input type="text" class="form-control" id="v_prize" name="v_prize">
                            </div>
                            <div class="form-group">
                                <label for="v_ex_date" class="col-form-label">Voucher Ex.Date</label>
                                <input type="date" class="form-control" id="v_ex_date" name="v_ex_date">
                            </div>
                            <div class="form-group">
                                <label for="t&c" class="col-form-label">Voucher T&C</label>
                                <input type="text" class="form-control" id="t_can" name="t_can">
                            </div>


                        <button type="submit" class="btn btn-primary"> Update </button>


                        <a href="{{ url('/vouchers')}}" class="btn btn-danger"> Cancle </a>

                    </div>
                </form>

            </div>
        </div>
    </div>
</div>



@endsection


@section('scripts')

@endsection
