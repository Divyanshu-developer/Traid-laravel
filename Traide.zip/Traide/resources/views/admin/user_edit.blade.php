@extends('layouts\master')


@section('title')
    User Edit|Form
@endsection

@section('content')

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"> User Edit Form</h4>
                </div>

                <div class="card-body">

                        @if ($errors->count() > 0)
                            <ul>
                                @foreach($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        @endif

                    <form action="{{ route('/user_update/{id}',$users->id)}}" method="post">
                        {{ csrf_field() }}

                        <div class="panel-body">
                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" class="form-control" name="name" id="name" placeholder="Name" value="{{$users->name}}">
                        </div>
                        <div class="form-group">
                            <label>Email address</label>
                            <input type="email" class="form-control" name="email" id="email" placeholder="Enter email">
                        </div>
                        <div class="form-group">
                            <label>Phone No</label>
                            <input type="tel" class="form-control" name="phone" id="phone" placeholder="Enter Phone no">
                        </div>

                            <button type="submit" class="btn btn-primary"> Update </button>
{{--                        <a href="{{ url('/user_update', $users->id) }}" class="btn btn-primary"> Update </a>--}}


                             <a href="{{ url('/users')}}" class="btn btn-danger"> Cancle </a>

                        </div>
                    </form>

            </div>
        </div>
    </div>
    </div>


@endsection


@section('scripts')

@endsection
